#include <iostream>

extern int yyparse();

int main() {
    std::cout << "Enter expression (e.g., F = ke * (q1 + q2) / (r ^ 2);):\n";
    yyparse();
    return 0;
}
