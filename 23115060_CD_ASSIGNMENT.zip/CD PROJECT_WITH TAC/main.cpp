#include <iostream>

extern int yyparse();

int main() {
    std::cout << "Enter expression (e.g., COULOMB F = 9e9, 1.6e-19, 1.6e-19, 0.05;):\n";
    yyparse();
    return 0;
}
